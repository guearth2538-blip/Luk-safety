# IllumiSafe Cloud One URL v2

## สิ่งที่เพิ่ม
- Login/JWT
- Role: ADMIN/OFFICER/REVIEWER/VIEWER
- PostgreSQL
- Upload สูงสุด 5 รูป
- เปิดดูรูปจาก URL กลาง
- Audit Log
- PDF/Print report
- Dashboard/History ใช้ฐานกลาง

## การ Deploy
1. สร้าง PostgreSQL
2. ตั้ง DATABASE_URL และ JWT_SECRET
3. รัน schema.sql
4. รัน seed.sql หลังตรวจสอบ hash บัญชี Admin
5. `npm install`
6. `npm start`
7. ผูก HTTPS + Domain
8. ส่ง URL ให้ผู้ใช้

## สำคัญก่อน Go-Live
- เปลี่ยน demo admin password/hash
- ใช้ JWT_SECRET แบบสุ่มยาว
- ไม่เปิด storage ตรงโดยไม่ผ่าน auth
- ตั้ง backup PostgreSQL
- ตั้ง object storage สำหรับไฟล์จริง
- ตรวจ Master Data กับไฟล์แสง.xlsx และเอกสารทางการก่อนล็อกค่า Production
- PDF ในรุ่นนี้เป็น HTML-to-print foundation; ถ้าต้องการ PDF ที่จัดหน้าราชการจริง ให้ใช้ Chromium/Playwright หรือ PDF service ใน deployment
