-- Extracted from uploaded file: แสง(1).xlsx, sheet: UCL ใหม่
-- Review/approve against official legal publication before Go-Live.
delete from illumination_standards;
insert into illumination_standards(work_name,standard_average,standard_minimum,source) values('ทางเดิน',300,150,'แสง(1).xlsx / UCL ใหม่');
insert into illumination_standards(work_name,standard_average,standard_minimum,source) values('ทางเดิน',100,50,'แสง(1).xlsx / UCL ใหม่');
insert into illumination_standards(work_name,standard_average,standard_minimum,source) values('บันได',100,50,'แสง(1).xlsx / UCL ใหม่');
insert into illumination_standards(work_name,standard_average,standard_minimum,source) values('ประชาสัมพันธ์',300,150,'แสง(1).xlsx / UCL ใหม่');
insert into illumination_standards(work_name,standard_average,standard_minimum,source) values('ประตูทางเข้า',50,0,'แสง(1).xlsx / UCL ใหม่');
insert into illumination_standards(work_name,standard_average,standard_minimum,source) values('ลิฟต์',100,0,'แสง(1).xlsx / UCL ใหม่');
insert into illumination_standards(work_name,standard_average,standard_minimum,source) values('ห้องควบคุมและห้องสวิตช์',200,100,'แสง(1).xlsx / UCL ใหม่');
insert into illumination_standards(work_name,standard_average,standard_minimum,source) values('ห้องถ่ายเอกสาร',100,50,'แสง(1).xlsx / UCL ใหม่');
insert into illumination_standards(work_name,standard_average,standard_minimum,source) values('ห้องถ่ายเอกสาร',300,150,'แสง(1).xlsx / UCL ใหม่');
insert into illumination_standards(work_name,standard_average,standard_minimum,source) values('ห้องประชุม',300,150,'แสง(1).xlsx / UCL ใหม่');
insert into illumination_standards(work_name,standard_average,standard_minimum,source) values('ห้องสุขา',100,50,'แสง(1).xlsx / UCL ใหม่');
insert into illumination_standards(work_name,standard_average,standard_minimum,source) values('ห้องเก็บของ',100,50,'แสง(1).xlsx / UCL ใหม่');
insert into illumination_standards(work_name,standard_average,standard_minimum,source) values('โถงลิฟต์',100,50,'แสง(1).xlsx / UCL ใหม่');
